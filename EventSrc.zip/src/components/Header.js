import React ,{useState}from 'react'
import {AppBar, Box, Divider, Drawer, IconButton, Toolbar, Typography} from '@mui/material'
import FastfoodIcon from '@mui/icons-material/Fastfood';
import {Link} from 'react-router-dom';
import "../styles/HeaderStyle.css";
import MenuIcon from '@mui/icons-material/Menu';

const Header = () => {
  const[mobileOpen,setMobileOpen]=useState(false)
  //handle menu click
  const handleDrawerToggle=()=>{
    setMobileOpen(!mobileOpen)
  }
  //menu drawer
  const drawer=(

    <Box onClick={handleDrawerToggle} sx={{textAlign:'center'}}>
     <Typography color={'goldenrod'} 
     variant='h6'
      component="div" 
      sx={{flexGrow:1,my:2}}>
          <FastfoodIcon/>
         
          </Typography>
          <Divider/>
          
            <ul className='mobile-navigation'>
              {/* <li>
                <Link activeClassName="active" to={'/'}>Home</Link>
              </li> */}
              <li>
              <Link activeClassName="active" to={'/about'}>About Us</Link>
              </li>
               <li>
              <Link activeClassName="active" to={'/about'}>Service</Link>
              </li>
              <li>
              <Link activeClassName="active" to={'/about'}>Gallery</Link>
              </li>
              
              <li>
              <Link to={'/contact'}>Contact Us</Link>
              </li>
            </ul>
          </Box>
  )
  return (
    <>
   
    <Box>
      <AppBar component={'nav'} sx={{bgcolor:"white"}}>
        <Toolbar>
          <IconButton color="inherit" aria-label="open drawer" edge="start" sx={{mr:2,display:{sm:"none"}}}
          onClick={handleDrawerToggle}>
             <MenuIcon/>
          </IconButton>
        <Typography color={'goldenrod'} variant='h6' component="div" sx={{flexGrow:1}}>
           <FastfoodIcon/>
          <a href='/'>CELEBRATION </a>
          </Typography>
          <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
        <ul className='navigation-menu list-unstyled'>
          <li className='nav-item'>
            <Link to={'/about'} className='nav-link text-black fw-bold'>
              About Us
            </Link>
          </li>
          <li className='nav-item'>
            <Link to={'/cources'} className='nav-link text-black fw-bold'>
              Service
            </Link>
            </li>
          <li className='nav-item'>
            <Link to={'/notice'} className='nav-link text-black fw-bold'>
             Gallery
            </Link>
          </li>
          {/* <li className='nav-item'>
            <Link to={'/event'} className='nav-link text-black fw-bold'>
             
            </Link>
          </li> */}
          <li className='nav-item'>
            <Link to={'/contact'} className='nav-link text-black fw-bold'>
              Enquiry
            </Link>
          </li>
        </ul>
      </Box>

       </Toolbar>   
       </AppBar>
       <Box component="nav">
        <Drawer variant="temporary" 
        open={mobileOpen}
         onClose={handleDrawerToggle} 
         sx={{display:{xs:'block',sm:'none'},"&.MuiDrawer-paper":{
          boxSizing:"border-box",
          width:"240px",
         },
         }}>
          {drawer}
        </Drawer>
        
       </Box>
       <Box sx={{p:1}}>
       <Toolbar/>
       </Box>
       
    </Box>
    </>
  )
};

export default Header