import React from 'react'
import Layout from '../components/Layout/Layout'

const Notice = () => {
  return (
  <Layout>
    <h1>Notice</h1>
  </Layout>
  )
}

export default Notice
