import React from 'react'
import Layout from '../components/Layout/Layout'

const Pagenotfound = () => {
  return (
    <Layout>
        <h1>page notfound page</h1>
    </Layout>
  )
}

export default Pagenotfound