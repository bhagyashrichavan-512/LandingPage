import React ,{useState} from 'react'
import Layout from '../components/Layout/Layout'
import { Box, Card, CardActionArea, CardContent, CardMedia, Typography } from '@mui/material'
import {MenuList} from '../data/data'

const Menu = () => {

  const serviceImages = [
    { path: 'a.jpg', name: 'Software Engineering', link: 'https://collegedunia.com/courses/software-engineering/syllabus' },
    { path: 'A1.jpg', name: 'Art And Design', link: '/art-and-design' },
    { path: 'HD.jpg', name: 'Mechanical Engineering', link: '/mechanical-engineering' },
    { path: 'HD1.avif', name: 'Law', link: '/law' },
    // Add more image paths, names, and links as needed
  ];

  const handleImageClick = (link) => {
    window.location.href = link;
  };
  const [hoveredIndex, setHoveredIndex] = useState(null);
  return (
    <Layout>
      <div id="features" className="text-center">
  <div className="container">
    <div className="col-md-10 col-md-offset-1 section-title">
    <h2 className="text-black" style={{  marginLeft: '20%' }}>
    Popular Courses
    </h2>

    </div>
  </div>
</div>
<br/>

    <div className="container">
      <div className="row justify-content-center">
        {serviceImages.map((service, index) => (
          <div
            className="col-3 text-center"
            key={index}
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <div className="overflow-hidden mx-auto mb-3" style={{ width: '250px', height: '250px' }}>
            <a href={service.link} onClick={() => handleImageClick(service.link)}>
              <img src={service.path} alt={service.name} className="w-100 h-100 object-fit-cover" 
              
              style={{
    
                transition: 'transform 0.2s',  // Add a smooth transition effect
              }}
              onMouseOver={(e) => {
                e.target.style.transform = 'scale(1.1)';  // Zoom in the image on hover
              }}
              onMouseOut={(e) => {
                e.target.style.transform = 'scale(1)';   // Reset to normal size when mouse leaves
              }}/>
              </a>
            </div>
            <h2>{hoveredIndex === index ? service.name : ''}</h2>
          </div>
        ))}
      </div>
    </div>

    </Layout>
  )
}

export default Menu