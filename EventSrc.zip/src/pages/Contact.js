import React from 'react'
import Layout from '../components/Layout/Layout'
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
import EmailIcon from '@mui/icons-material/Email';
import CallIcon from '@mui/icons-material/Call';

import { 
  Box,
   Paper,
    TableCell,
    Table, TableContainer, TableRow, Typography, TableBody, TableHead } from '@mui/material';


const Contact = () => {
  return (
    <Layout>
        <Box sx={{my:5,ml:10,"& h4":{fontWeight:"bold",mb:2}}}>
          <Typography variant='h4'> Contact My Restuarant</Typography>
            
            <p>
            While searching for different types of basic restaurant management theories, you'll inevitably find arguments promoting one management style as being ideal over another. The truth of the matter is that no one management style will work for all restaurants. A major contributing factor in determining which theories will work and which ones won't is the overall culture of restaurant and the type of leadership the staff requires.

Autocratic
            </p>
         </Box>
         <Box sx={{m:3,width:"600px",ml:10,"@media(max-width:600px)":{
          width:'300px'
         }}}>
          <TableContainer component={Paper}>
            <Table aria-label="contact table">
              <TableHead >
                <TableRow>
                  <TableCell sx={{bgcolor:'black',color:'white',}} align='center'>Contact Details</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>
                    <SupportAgentIcon sx={{color:'red',pt:1}} /><b>7666-7422-62(tollfree)</b>
                  </TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell>
                    <EmailIcon sx={{color:'skyblue',pt:1}} /><b>helpmybhagyarest@gmail.com</b>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>
                    <CallIcon sx={{color:'green',pt:1}} /><b>9322350092</b>
                  </TableCell>
                  
                </TableRow>
              </TableBody>

            </Table>

          </TableContainer>
         </Box>
    </Layout>
  )
}

export default Contact