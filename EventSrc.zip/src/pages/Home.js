import React from 'react'
import Layout from '../components/Layout/Layout'
import {Link} from "react-router-dom";
import Banner from '../banner.jpg'
import "../styles/HomeStyle.css";
import { Container, Row, Col } from 'react-bootstrap';
import  { useState, useEffect } from 'react';



import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';


const Home = () => {
  const [index, setIndex] = useState(0);
  const images = ['b8.jpg','b9.jpg','b3.jpg', 'b2.jpg', 'b1.jpg','b5.jpg','b6.webp','b8.jpg','b9.jpg','b10.webp'];
  
  // Use useEffect to increment the index and update the image every 5 seconds
  useEffect(() => {
    const intervalId = setInterval(() => {
      setIndex(prevIndex => (prevIndex + 1) % images.length);
    }, 5000);
  
    return () => clearInterval(intervalId);
  }, []);
  const serviceImages = [
    { path: 'b2.jpg', name: 'Celebration Event ', link: 'https://collegedunia.com/courses/software-engineering/syllabus' },
    { path: 'b5.jpg', name: 'Holl Booking', link: '/art-and-design' },
    { path: 'b12.jpg', name: 'Catring', link: '/mechanical-engineering' },
    { path: 'b14.jpg', name: 'Photography', link: '/law' },
    // Add more image paths, names, and links as needed
  ];

  const handleImageClick = (link) => {
    window.location.href = link;
  };
  const [hoveredIndex, setHoveredIndex] = useState(null);



  const galleryImages = [
    "b3.jpg",
    "b7.jpg",
    "b8.jpg",
    "b14.jpg",
    "b13.webp",
    "b1.jpg",
  ];
  
  return (
    <Layout>
    
<img
  src={images[index]}
  alt={`Image ${index}`}
  style={{ width: '100%', height: '600px' }}
/>
<br/><br/>
<div id="features" className="text-center">
  <div className="container">
    <div className="col-md-10 col-md-offset-1 section-title">
    <h1 className="text-black" style={{  marginLeft: '20%' }}>
    Events
    </h1>

    </div>
  </div>
</div>
<br/>

    <div className="container">
      <div className="row justify-content-center">
        {serviceImages.map((service, index) => (
          <div
            className="col-3 text-center"
            key={index}
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <div className="rounded-circle overflow-hidden mx-auto mb-3" style={{ width: '250px', height: '250px' }}>
            <a href={service.link} onClick={() => handleImageClick(service.link)}>
              <img src={service.path} alt={service.name} className="w-100 h-100 object-fit-cover" 
              
              style={{
    
                transition: 'transform 0.2s',  // Add a smooth transition effect
              }}
              onMouseOver={(e) => {
                e.target.style.transform = 'scale(1.1)';  // Zoom in the image on hover
              }}
              onMouseOut={(e) => {
                e.target.style.transform = 'scale(1)';   // Reset to normal size when mouse leaves
              }}/>
              </a>
            </div>
            <h2>{hoveredIndex === index ? service.name : ''}</h2>
          </div>
        ))}
      </div>
    </div>


<br></br>

<Container className="my-5">
      <Row>
        <Col md={6}>
        <img
  src="b3.jpg"
  className="img-fluid"
  alt="About Us"
  style={{
    
    transition: 'transform 0.2s',  // Add a smooth transition effect
  }}
  onMouseOver={(e) => {
    e.target.style.transform = 'scale(1.1)';  // Zoom in the image on hover
  }}
  onMouseOut={(e) => {
    e.target.style.transform = 'scale(1)';   // Reset to normal size when mouse leaves
  }}
/>
        </Col>
        <Col md={6}>
          <h1>  ABOUT US</h1>
          <h2>Innovative Way To Learn</h2>
          <p>
        

   Aliquyam accusam clita nonumy ipsum sit sea clita ipsum clita, ipsum dolores amet voluptua duo dolores et sit ipsum rebum, sadipscing et erat eirmod diam kasd labore clita est. Diam sanctus gubergren sit rebum clita amet, sea est sea vero sed et. Sadipscing labore tempor at sit dolor clita consetetur diam. Diam ut diam tempor no et, lorem dolore invidunt no nonumy stet ea labore, dolor justo et sit gubergren diam sed sed no ipsum.
  Sit tempor ut nonumy elitr dolores justo aliquyam ipsum stet
          </p>
        
        </Col>
      </Row>
    </Container>

{/* Event */}
    <Container className="my-5">
    <h2 className="text-black" style={{  marginLeft: '50%' }}>
      Gallery
    </h2>
      <Row>
        {galleryImages.map((image, index) => (
          <Col md={4} key={index}>
            
            <img
  src={image}
  className="img-fluid mb-3"
  alt={`Gallery Image ${index + 1}`}
  style={{
    height: '80%',
    transition: 'transform 0.2s',  // Add a smooth transition effect
  }}
  onMouseOver={(e) => {
    e.target.style.transform = 'scale(1.1)';  // Zoom in the image on hover
  }}
  onMouseOut={(e) => {
    e.target.style.transform = 'scale(1)';   // Reset to normal size when mouse leaves
  }}
/>
          </Col>
        ))}
      </Row>
    </Container>

    {/* contact us */}

    <div className="row" style={{ backgroundImage: 'url("blur1.jpg")', backgroundSize: 'cover', backgroundPosition: 'center', height: '100vh' }}>
  <div className="col-lg- d-flex justify-content-center align-items-center">
  <div className="card w-50">
      <div className="card-body">
        <h2 className="card-title text-center mb-4">Contact Us</h2>
        <form>
          <div className="mb-3">
            <label htmlFor="name" className="form-label text-center ">Name</label>
            <input type="text" className="form-control" id="name" />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label text-center">Email</label>
            <input type="email" className="form-control" id="email" />
          </div>
          <div className="mb-3">
            <label htmlFor="message" className="form-label text-center">Message</label>
            <textarea className="form-control" id="message" rows="5"></textarea>
          </div>
          <div className="d-flex justify-content-center">
        <button type="submit" className="btn btn-dark">Submit</button>
      </div>
        </form>
      </div>
    </div>
  </div>

</div>


  
    <br/>
  

    {/* // Footer.js */}

    {/* <footer className="bg-dark text-white py-4">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <h3>Contact Us</h3>
            <p>123 Main Street, City, Country</p>
            <p>Email: example@example.com</p>
            <p>Phone: +1234567890</p>
          </div>
          <div className="col-md-6">
            <h3>Follow Us</h3>
            <ul className="list-unstyled d-flex justify-content-start mb-0">
              <li className="me-3">
                <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer"> Facebook
                  <i className="fab fa-facebook-f"></i>
                </a>
              </li>
              <li className="me-3">
                <a href="https://www.twitter.com/" target="_blank" rel="noopener noreferrer"> twitter
                  <i className="fab fa-twitter"></i>
                </a>
              </li>
              <li className="me-3">
                <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer"> instragram
                  <i className="fab fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer> */}
 


    </Layout>
  )
}

export default Home