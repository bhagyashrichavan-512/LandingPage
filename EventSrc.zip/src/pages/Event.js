import React from 'react'
import Layout from '../components/Layout/Layout'
const Event = () => {
  return (
   
    <Layout>
      event page
      </Layout>
    
  )
}

export default Event
