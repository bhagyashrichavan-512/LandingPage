import React from 'react'
import Layout from '../components/Layout/Layout'
import { Box, Typography } from '@mui/material';
import { Container, Row, Col } from 'react-bootstrap';


const About = () => {
  return (
    <Layout>
        {/* <Box sx={{my:15,
        textAlign:"center",
        "& h4":{
          fontFamily:'bold',
          my:2,
          fontSize:"2rem",
        },
        "& p":{
          textAlign:"justify",
        },
        "@media (max-width:600px)":{
          mt:0
        }
        }}>
          <Typography variant="h4">
            <b>Welcome to My Resturant</b>
          </Typography>
          <p>While searching for different types of basic restaurant management theories, you'll inevitably find arguments promoting one management style as being ideal over another. The truth of the matter is that no one management style will work for all restaurants. A major contributing factor in determining which theories will work and which ones won't is the overall culture of restaurant and the type of leadership the staff requires.

Autocratic</p>
          <br/>
          <p>
          While searching for different types of basic restaurant management theories, you'll inevitably find arguments promoting one management style as being ideal over another. The truth of the matter is that no one management style will work for all restaurants. A major contributing factor in determining which theories will work and which ones won't is the overall culture of restaurant and the type of leadership the staff requires.

Autocratic
          </p>
        </Box> */}

<Container className="my-5">
      <Row>
        <Col md={6}>
        <img
  src="b11.jpg"
  className="img-fluid"
  alt="About Us"
  style={{
    
    transition: 'transform 0.2s',  // Add a smooth transition effect
  }}
  onMouseOver={(e) => {
    e.target.style.transform = 'scale(1.1)';  // Zoom in the image on hover
  }}
  onMouseOut={(e) => {
    e.target.style.transform = 'scale(1)';   // Reset to normal size when mouse leaves
  }}
/>
        </Col>
        <Col md={6}>
          <h1>  ABOUT US</h1>
          <h2>Innovative Way To Learn</h2>
          <p>
        

   Aliquyam accusam clita nonumy ipsum sit sea clita ipsum clita, ipsum dolores amet voluptua duo dolores et sit ipsum rebum, sadipscing et erat eirmod diam kasd labore clita est. Diam sanctus gubergren sit rebum clita amet, sea est sea vero sed et. Sadipscing labore tempor at sit dolor clita consetetur diam. Diam ut diam tempor no et, lorem dolore invidunt no nonumy stet ea labore, dolor justo et sit gubergren diam sed sed no ipsum.
  Sit tempor ut nonumy elitr dolores justo aliquyam ipsum stet
          </p>
        
        </Col>
      </Row>
    </Container>
    <Container className="my-5" >
      <Row>
        <Col md={6}>
          <h2>Goals to Achieve for the leadership</h2>
          <p>
          Nunc placerat mi id nisi interdum mollis. Praesent pharetra, justo ut scelerisque mattis, leo quam aliquet diam, congue laoreet elit metus eget diam. Proin ac metus diam
          </p>
          <p>
            With a wide range of programs and extracurricular activities, we strive to prepare our students
            for success in their future careers.
          </p>
        </Col>
        <Col md={6}>
       
          <img
            src="b3.jpg"
            className="img-fluid"
            alt="College Campus"
            style={{
    
              transition: 'transform 0.2s',  // Add a smooth transition effect
            }}
            onMouseOver={(e) => {
              e.target.style.transform = 'scale(1.1)';  // Zoom in the image on hover
            }}
            onMouseOut={(e) => {
              e.target.style.transform = 'scale(1)';   // Reset to normal size when mouse leaves
            }}
          />
          
        </Col>
      </Row>
    </Container>

    </Layout>
  );
};

export default About