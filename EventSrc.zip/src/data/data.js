import chola from '../chola.jpg'
import dosa from '../dosa.jpg'
import idli from '../idli.png'
import Gujrathi from '../Gujrathi.jpg'
import Masaladosa from '../Masala-dosa.jpg'
import paneer from '../paneer.jpg'

export const MenuList=[
    {
        name:'Dosa',
        description: 'Dosas originated in Karnataka. According to historian P. Thankappan Nair, dosa originated in the town of Udupi in present-day Karnataka',
        image:dosa,
        price:200
    },
    {
        name:'chola',
        description:'Chole bhature is a food dish popular in the Northern areas of the Indian subcontinent.[1] It is a combination of chana masala',
        image:chola,
        price:300
    },
    {
        name:'idli',
        description:'Idli or idly (plural: idlis) is a type of savoury rice cake, originating from South India, popular as a breakfast food in Southern India and in Sri Lanka',
        image:idli,
        price:150
    },
    {
        name:'Gujrathi',
        description:'Gujarati Thali (Gujarati: ગુજરાતી થાળી) is an assortment of dishes arranged as a platter for lunch or dinner in restaurants and homes, mostly in Gujarat...',
        image:Gujrathi,
        price:400
    },
    {
        name:'Masaladosa',
        description:'A properly made crisp and savory Indian dosa is wonderfully delicious, and fairly simple to make at home, with this caveat:',
        image:Masaladosa,
        price:200
    },
    {
        name:'paneer',
        description:'aneer dishes [ edit] Paneer pulao (paneer with rice) Mattar paneer (paneer with peas) Shahi paneer (paneer cooked in a rich Mughlai curry) Paneer tikka',
        image:paneer,
        price:350
    },
    

    
];

